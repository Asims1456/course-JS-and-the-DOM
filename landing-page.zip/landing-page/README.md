## Landing Page Project

In this Landing Page project we change the webpage from staitic to dynamic.

## Landing Page Project Discription

In this project I built a multi-section landing page. The navigational menu was dynamically updated as well to refex the amount of content added to the page. I also updated the CSS to make it more responsive.


## Usage in the Landing Page project

- make the webpage responsive on all devices.
- Ensure the navigation bar is responsive as well.
- The use of Chrome Dev Tool should be used to achieve responsiveness.

## Landing Project Dependencies

- Navigation is built dynamically as an unordered list.
- Each section of the landing page should have a Section Active State.
- Scroll to Anchor effect with event listner.
- Added the event.preventDefault()

